Datasets used in Jupyter notebook

5 above and 1 large linked below

https://www.kaggle.com/datasets/pyatakov/india-agriculture-crop-production/data
