Small working prototype of loca Streamlit App. Here we use soil and climate parameters and trained it using lightBGM method to predict optimal crop for the season.

![Agri](agriculture.jpg)

Prototype Runned on local Streamlit App.

![Streamlit](demo.png)
