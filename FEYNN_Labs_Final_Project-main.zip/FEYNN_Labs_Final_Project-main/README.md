# FEYNN_Labs_Final_Project
FEYNN Labs Final Project of AI in Agriculture

Few Renders and Map were not uploaded in GitHub hence in case you have to view them then click Colab Link mentioned in ipynb file.
